# RAKU

An interface and a partially working model of my personal project - RAKU.
